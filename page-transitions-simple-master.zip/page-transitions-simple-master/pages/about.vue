<template>
  <div class="container">
    <h1>About page</h1>
    <nuxt-link to="/">Home page</nuxt-link>
  </div>
</template>

<script>
// export default {
//   transition: 'bounce'
// }
</script>